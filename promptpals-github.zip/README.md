# PromptPals

Free AI micro-tools and prompt generators. A plain static website (HTML, CSS and JavaScript) with no backend, no build step and no dependencies.

## What's inside

| File | Purpose |
| --- | --- |
| `index.html` | Home page with the 13 tools, search, saved prompts and templates |
| `guides.html` | Prompt guides (add more articles over time) |
| `about.html`, `privacy.html`, `contact.html` | Pages AdSense expects |
| `style.css` | All styling (light and dark mode) |
| `app.js` | Tools, credit system, saved prompts and history |
| `robots.txt`, `sitemap.xml` | Search engine files |

## Run it locally

Download the repo, keep all files in one folder, and double-click `index.html`.

## Credits

Each visitor gets 500 credits per month (reset on the 1st) plus 50 on each new day they visit, capped at 500. Balances are stored in the visitor's browser (local storage), so they are a usage meter, not a secure balance. Tool costs are in the `COST` object near the top of `app.js`.

## Deploy

Import this repository on [vercel.com](https://vercel.com) (Add New, then Project). No framework or build settings are needed: leave everything as default and click Deploy. Cloudflare Pages also works the same way.

## Before applying for AdSense

- [ ] Search the files for `EDIT` and fill in your email, site name and About text
- [ ] Replace `YOURDOMAIN.com` in `robots.txt` and `sitemap.xml`
- [ ] Add more original guides to `guides.html`
- [ ] Connect your own domain
- [ ] After approval, uncomment the AdSense script in the `<head>` of every page and replace the two "Ad space" boxes in `index.html` with your ad code
